class Gym {
    constructor() {
        this.id = 0;
        this.nome = "";
        this.telefone = "";
        this.bodybuilders = []; //associar o bodybuilder ao gym

    }    
} module.exports = {Gym};