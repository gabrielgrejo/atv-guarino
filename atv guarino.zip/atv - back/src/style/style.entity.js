

class Style {
  constructor() {
    this.id = 0;
    this.nome = "";
    this.bodybuilders = [];
  }
}
module.exports = { Style };
